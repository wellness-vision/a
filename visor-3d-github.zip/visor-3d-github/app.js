const viewer = document.querySelector('#viewer');
const error = document.querySelector('#error');
const progress = document.querySelector('#progress');
const rotate = document.querySelector('#rotate');

viewer.addEventListener('progress', ({ detail }) => {
  progress.style.width = `${Math.round(detail.totalProgress * 100)}%`;
});
viewer.addEventListener('error', () => { error.hidden = false; });
viewer.addEventListener('load', () => { error.hidden = true; });

document.querySelector('#reset').addEventListener('click', () => {
  viewer.autoRotate = false;
  rotate.setAttribute('aria-pressed', 'false');
  rotate.querySelector('span').textContent = 'Giro automático: no';
  viewer.cameraOrbit = 'auto auto auto';
  viewer.cameraTarget = 'auto auto auto';
  viewer.fieldOfView = 'auto';
  viewer.jumpCameraToGoal();
});
rotate.addEventListener('click', () => {
  viewer.autoRotate = !viewer.autoRotate;
  rotate.setAttribute('aria-pressed', String(viewer.autoRotate));
  rotate.querySelector('span').textContent = `Giro automático: ${viewer.autoRotate ? 'sí' : 'no'}`;
});
document.querySelector('#fullscreen').addEventListener('click', async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.querySelector('.viewer-wrap').requestFullscreen();
  } catch (e) { console.warn('Pantalla completa no disponible', e); }
});
