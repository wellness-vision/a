# Visor 3D para GitHub Pages

Web estática lista para publicar el modelo `models/modelo.glb` en un visor 3D interactivo, con controles de órbita, zoom, giro automático, reinicio de cámara y pantalla completa.

## Publicar en GitHub Pages

1. En [GitHub](https://github.com/new), crea un repositorio (por ejemplo, `visor-3d`). Configúralo como **Public** si quieres que cualquiera pueda visitar el visor.
2. Sube **el contenido de esta carpeta**, manteniendo `index.html`, `app.js`, `styles.css` y la carpeta `models/` en sus rutas actuales. También puedes subir el ZIP descomprimido mediante Git o GitHub Desktop.
3. Ve a **Settings → Pages** del repositorio.
4. En **Build and deployment**, selecciona **Deploy from a branch**, rama **main**, carpeta **/(root)**, y pulsa **Save**.
5. Tu visor estará disponible en `https://TU_USUARIO.github.io/NOMBRE_REPOSITORIO/` una vez publicado.

> El archivo `.nojekyll` evita procesamiento innecesario por Jekyll. El visor usa la librería `<model-viewer>` desde un CDN: los visitantes necesitan conexión a Internet.

## Probarlo localmente

Por motivos de seguridad del navegador, no abras `index.html` directamente con `file://`. Desde esta carpeta ejecuta:

```bash
python -m http.server 8000
```

Abre `http://localhost:8000`.

## Archivos

- `index.html`: página principal del visor.
- `styles.css`: diseño adaptable a móvil y escritorio.
- `app.js`: interacciones del visor.
- `models/modelo.glb`: modelo original, sin modificaciones.
- `.nojekyll`: configuración de GitHub Pages.

## Nota técnica

El GLB incluye la extensión heredada `KHR_materials_pbrSpecularGlossiness`. El visor intenta cargarla mediante la biblioteca indicada. Si alguna superficie se muestra distinta a la aplicación de origen, puede ser necesaria una conversión a materiales glTF PBR metallic-roughness.
